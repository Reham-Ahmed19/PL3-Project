#!/usr/bin/env python3
# how to run 
# streamlit run app.py
## dotnet fsi ApiServer.fsx 

"""
Simple Store Simulator - Frontend Launcher
Run this script to start the Streamlit application easily
"""
import subprocess
import time
import os

# Paths relative to THIS run.py file
base_dir = os.path.dirname(os.path.abspath(__file__))
backend_path = os.path.join(base_dir, "..", "backend", "src")
frontend_path = base_dir  # current folder

# Start Backend
print("Starting F# Backend...")
subprocess.Popen(
    ["cmd", "/k", "dotnet fsi ApiServer.fsx"],
    cwd=backend_path
)

# Wait for backend to boot
time.sleep(4)

# Start Frontend
print("Starting Streamlit Frontend...")
subprocess.Popen(
    ["cmd", "/k", "streamlit", "run", "app.py"],
    cwd=frontend_path
)

print("\nSimple Store project is running!")
