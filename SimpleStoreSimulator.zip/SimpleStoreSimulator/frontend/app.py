import streamlit as st
import requests
import pandas as pd
import json
import uuid
import time

# --- CONFIGURATION ---
API_BASE_URL = "http://localhost:8080/api"
st.set_page_config(page_title="Simple Store Simulator", layout="wide", page_icon="🛍️")

# --- STATE MANAGEMENT ---
if 'session_id' not in st.session_state:
    st.session_state['session_id'] = str(uuid.uuid4())

if 'user' not in st.session_state:
    st.session_state['user'] = None  # { 'username': str, 'role': 'user'|'admin', 'userId': int }

if 'cart_updated' not in st.session_state:
    st.session_state['cart_updated'] = False

# --- API HELPERS ---
def api_get(endpoint, params=None):
    headers = {"X-Session-ID": st.session_state['session_id']}
    try:
        response = requests.get(f"{API_BASE_URL}{endpoint}", params=params, headers=headers)
        if response.status_code == 200:
            return response.json()
    except:
        pass
    return None

def api_post(endpoint, data):
    headers = {"X-Session-ID": st.session_state['session_id'], "Content-Type": "application/json"}
    try:
        response = requests.post(f"{API_BASE_URL}{endpoint}", json=data, headers=headers)
        return response
    except Exception as e:
        st.error(f"API Error: {e}")
        return None

def api_delete(endpoint):
    headers = {"X-Session-ID": st.session_state['session_id']}
    try:
        response = requests.delete(f"{API_BASE_URL}{endpoint}", headers=headers)
        return response
    except:
        return None

# --- PAGES ---

def login_register_page():
    st.title("🔐 Login / Register")
    
    tab1, tab2 = st.tabs(["Login", "Register"])
    
    with tab1:
        with st.form("login_form"):
            username = st.text_input("Username")
            password = st.text_input("Password", type="password")
            submit = st.form_submit_button("Login")
        
        # Handle login outside the form so messages persist
        if submit:
            res = api_post("/login", {"username": username, "password": password})
            if res and res.status_code == 200:
                data = res.json()
                st.session_state['user'] = {
                    'username': data['username'],
                    'role': data['role'], # 'admin' or 'user'
                    'userId': data['userId']
                }
                st.success(f"Welcome back, {data['username']}!")
                st.rerun()
            else:
                # Extract specific error message from response
                try:
                    error_msg = res.json().get("message", "Wrong Username")
                except:
                    error_msg = "Wrong Password"
                st.error(error_msg)

    with tab2:
        with st.form("register_form"):
            new_user = st.text_input("Username")
            new_pass = st.text_input("Password", type="password")
            confirm_pass = st.text_input("Confirm Password", type="password")
            submit_reg = st.form_submit_button("Register")
        
        # Handle registration outside the form so messages persist
        if submit_reg:
            if not new_user or not new_pass or not confirm_pass:
                st.error("Please fill in all fields.") 
            elif new_pass != confirm_pass:
                st.error("Passwords do not match!")
            else:
                res = api_post("/register", {"username": new_user, "password": new_pass})
                if res and res.status_code == 200:
                    st.success("Registration successful! Please login.")
                elif res:
                    # Extract error message from response
                    try:
                        error_msg = res.json().get("message", "Registration failed")
                    except:
                        error_msg = "Registration failed"
                    st.error(error_msg)
                else:
                    st.error("The Username is Already Taken")

def shop_page():
    st.title("🛍️ Catalog")

    # Custom CSS for consistent product images and card size
    st.markdown("""
        <style>
        [data-testid="stImage"] img {
            height: 200px !important;
            object-fit: contain !important;
        }
        div[data-testid="stVerticalBlockBorderWrapper"] {
            min-height: 550px;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
        }
        </style>
    """, unsafe_allow_html=True)
    
    # Search & Filter
    col1, col2, col3 = st.columns([2, 1, 1])
    with col1:
        search = st.text_input("🔍 Search Products")
    with col2:
        # Get categories (hardcoded or from API? API stats has it, but better to fetch distinct from products logic or hardcode common ones)
        # Using hardcoded for simplicity matching Types.fsx
        categories = ["All", "Drinks", "Dairy", "Bakery", "Snacks", "Fruits", "Vegetables", "Frozen", "Personal Care", "Household", "Other"]
        category = st.selectbox("Category", categories)
    with col3:
        sort_opts = ["Default", "Price: Low to High", "Price: High to Low", "Rating"]
        sort = st.selectbox("Sort By", sort_opts)
    
    # Fetch Products
    params = {}
    if search: params['search'] = search
    if category and category != "All": params['category'] = category
    if sort and sort != "Default": params['sort'] = sort
    
    products = api_get("/products", params)
    
    if not products:
        st.info("No products found.")
        return

    # Display Grid
    # Streamlit doesn't have native grid, using columns
    cols = st.columns(3)
    for idx, p in enumerate(products):
        with cols[idx % 3]:
            with st.container(border=True):
                # Image
                if p.get("image"):
                    st.image(p["image"], use_container_width=True, width=150)
                else:
                    st.markdown("📦 NO IMAGE")
                
                st.subheader(p["name"])
                st.caption(f"{p['brand']} | {p['category']}")
                
                # Price & Rating
                c1, c2 = st.columns(2)
                with c1:
                    if p.get("original_price"):
                        st.markdown(f"~~{p['original_price']:.2f} EGP~~")
                    st.markdown(f"**{p['price']:.2f} EGP**")
                with c2:
                    st.markdown(f"⭐ {p.get('rating', 'N/A')}")
                
                # Stock
                if p['stock'] > 0:
                    st.success(f"In Stock ({p['stock']})")
                    
                    # Logic to Hide Add to Cart for Admin
                    is_admin = False
                    if st.session_state['user'] and st.session_state['user']['role'].lower() == 'admin':
                        is_admin = True
                    
                    if not is_admin:
                        if st.button("Add to Cart", key=f"add_{p['id']}"):
                            # Add to cart API
                            if st.session_state['user']: # Assuming User or Guest
                                res = api_post("/cart/add", {"productId": p['id'], "quantity": 1})
                                if res and res.status_code == 200:
                                    st.toast(f"Added {p['name']} to cart!")
                                    st.session_state['cart_updated'] = True
                                elif res and res.status_code == 400:
                                    st.error(res.json().get("message", "Failed to add to cart"))
                                else:
                                    st.error("Failed to add to cart")
                            else:
                                st.warning("Please login to shop.")
                else:
                    st.error("Out Of Stock")

def cart_page():
    st.title("🛒 Your Cart")
    
    cart = api_get("/cart")
    
    if not cart or cart['itemCount'] == 0:
        st.info("Your cart is empty.")
        return

    # Display Items
    for item in cart['items']:
        with st.container(border=True):
            c1, c2, c3, c4, c5 = st.columns([1, 2, 1, 1, 1])
            with c1:
                st.markdown("📦")
            with c2:
                st.subheader(item['name'])
                st.caption(item['brand'])
            with c3:
                st.markdown(f"{item['price']:.2f} EGP")
                st.markdown(f"**{item['subtotal']:.2f} EGP**")
            with c4:
                # Update quantity
                # key is used to persist state. 
                # If update fails, we should revert the value in session_state and rerun so the UI shows the valid quantity.
                qty_key = f"qty_{item['id']}"
                new_qty = st.number_input("Qty", min_value=1, value=item['quantity'], key=qty_key)
                
                if new_qty != item['quantity']:
                    res = api_post("/cart/update", {"productId": item['id'], "quantity": new_qty})
                    if res and res.status_code == 200:
                         st.rerun()
                    elif res and res.status_code == 400:
                         # Stock invalid
                         msg = res.json().get("message", "Insufficient stock")
                         st.toast(msg, icon="⚠️")
                         time.sleep(1.5) # Allow toast to be seen before rerun forces refresh
                         # Reset widget value to previous valid quantity
                         st.session_state[qty_key] = item['quantity']
                         st.rerun()
                    else:
                         st.error("Failed to update..Insufficient stock")
            with c5:
                if st.button("Remove", key=f"rem_{item['id']}"):
                    api_post("/cart/remove", {"productId": item['id']})
                    st.rerun()

    st.divider()
    
    # Summary
    st.subheader("Order Summary")
    s1, s2 = st.columns(2)
    s1.markdown("Subtotal:")
    s2.markdown(f"{cart['subtotal']:.2f} EGP")
    
    if cart['totalDiscount'] > 0:
        s1.markdown("Discount:")
        s2.markdown(f"-{cart['totalDiscount']:.2f} EGP", help="Discounts applied")
    
    s1.markdown("Tax (10%):")
    s2.markdown(f"{cart['tax']:.2f} EGP")
    
    s1.markdown("### Total:")
    s2.markdown(f"### {cart['finalTotal']:.2f} EGP")
    
    st.divider()
    
    # Checkout
    st.subheader("Checkout")
    with st.form("checkout_form"):
        payment_method = st.selectbox("Payment Method", ["Cash", "Credit Card", "Instapay"])
        amount_paid = st.text_input("Amount Paid (EGP)", value=f"{cart['finalTotal']:.2f}")
        
        checkout_btn = st.form_submit_button("Confirm Payment")
        
        if checkout_btn:
            try:
                amount_val = float(amount_paid)
                total_required = float(cart['finalTotal'])
                
                if amount_val < 0:
                     st.error("Amount cannot be negative.")
                     res = None
                elif amount_val < total_required:
                     st.error(f"Insufficient Payment! You are short by {total_required - amount_val:.2f} EGP")
                     res = None
                else:
                    if amount_val > total_required:
                        st.info(f"You are paying {amount_val - total_required:.2f} EGP extra. Change will be calculated.")
                    
                    # If user is logged in, pass userId
                    payload = {
                        "paymentMethod": payment_method,
                        "amount": amount_val,
                        "userId": st.session_state['user']['userId'] if st.session_state['user'] else None
                    }
                    
                    res = api_post("/checkout", payload)
            except ValueError:
                st.error("Please enter a valid numeric amount")
                res = None
            
            if res and res.status_code == 200:
                result = res.json()
                st.session_state['last_invoice'] = result
                st.success("Payment Successful!")
                # Show receipt handled in rendering below or rerun
                st.rerun()
            elif res:
                st.error(res.json().get("message", "Checkout failed"))

    # Show Receipt if just checked out
    if 'last_invoice' in st.session_state:
        inv = st.session_state.pop('last_invoice')
        st.balloons()
        with st.expander("📄 View Receipt", expanded=True):
            st.markdown(f"### Receipt")
            st.success(inv['message'])
            st.json(inv['invoice'])
            st.markdown(f"**Total Paid: {inv['invoiceTotal']:.2f} EGP**")

def api_put(endpoint, data):
    headers = {"X-Session-ID": st.session_state['session_id'], "Content-Type": "application/json"}
    try:
        response = requests.put(f"{API_BASE_URL}{endpoint}", json=data, headers=headers)
        return response
    except Exception as e:
        st.error(f"API Error put: {e}")
        return None

def user_transactions_page():
    st.title("🧾 Your Transactions")
    user_id = st.session_state['user']['userId']
    
    txs = api_get(f"/checkouts/user/{user_id}")
    
    if not txs:
        st.info("No transaction history found.")
        return

    # Display as table
    st.dataframe(pd.DataFrame(txs)[['InvoiceId', 'CheckoutDate', 'TotalAmount', 'PaymentMethod', 'ItemsCount']])
    
    # Detail View
    st.divider()
    st.subheader("Transaction Details")
    sel_inv = st.selectbox("Select Invoice to View Details", [t['InvoiceId'] for t in txs])
    
    if sel_inv:
        # Find the selected transaction
        selected = next((t for t in txs if t['InvoiceId'] == sel_inv), None)
        if selected:
            # The 'InvoiceData' is a JSON string, we need to parse it
            try:
                data = json.loads(selected['InvoiceData'])
                st.write(f"**Date:** {selected['CheckoutDate']}")
                st.write(f"**Payment:** {selected['PaymentMethod']}")
                st.write(f"**Total:** {selected['TotalAmount']:.2f} EGP")
                 
                st.markdown("#### Items")
                for item in data['items']:
                    st.write(f"- {item['quantity']}x {item['productName']} ({item['brand']}) @ {item['unitPrice']:.2f} = {item['quantity'] * item['unitPrice']:.2f}")
                
                st.divider()
                st.write(f"Subtotal: {data['subtotal']:.2f}")
                st.write(f"Tax: {data['tax']:.2f}")
                st.write(f"**Final Total: {data['finalTotal']:.2f}**")
            except:
                st.error("Could not parse invoice details.")

def admin_dashboard():
    st.title("👑 Admin Dashboard")
    
    tab1, tab2, tab3 = st.tabs(["📦 Products", "📊 Statistics", "🧾 Transactions"])
    
    with tab1:
        st.subheader("Manage Products")
        
        # Add Product Form
        with st.expander("Add New Product"):
            with st.form("add_prod"):
                n = st.text_input("Name")
                b = st.text_input("Brand")
                c = st.selectbox("Category", ["Drinks", "Dairy", "Bakery", "Snacks", "Fruits", "Vegetables", "Frozen", "PersonalCare", "Household", "Other"])
                p = st.number_input("Price", value=0.0)
                op = st.number_input("Old Price (Optional)", value=0.0)
                s = st.number_input("Stock", value=0)
                # Remove widget-level min/max to allow manual validation of "9"
                r = st.number_input("Rating (0.0 - 5.0)", value=0.0, step=0.1)
                img = st.text_input("Image URL")
                desc = st.text_area("Description")
                
                if st.form_submit_button("Add Product"):
                    if not n.strip() or not b.strip():
                        st.error("Name and Brand cannot be empty.")
                    elif p <= 0:
                        st.error("Price must be greater than 0.")
                    elif op < 0 or s < 0:
                        st.error("Stock and Old Price cannot be negative.")
                    elif r < 0 or r > 5:
                         st.error("Rating must be between 0 and 5.")
                    else:
                        payload = {
                            "name": n, "brand": b, "category": c, "price": p, 
                            "oldPrice": op if op > 0 else None, "stock": s,
                            "description": desc, "rating": r, "imageUrl": img
                        }
                        res = api_post("/admin/products", payload)
                        if res and res.status_code == 200:
                            st.success("Product Added")
                            if s == 0:
                                st.info("Note: Product added but currently not for sale (Stock is 0).")
                        else:
                            st.error(res.json().get("message", "Failed to add product") if res else "Failed")
        
        # Update Product Form
        with st.expander("Update Product"):
             st.info("Enter Product ID to fetch details")
             up_id = st.number_input("Product ID", min_value=1, step=1, key="up_id")
             
             if st.button("Fetch Details"):
                 prod = api_get(f"/products/{up_id}")
                 if prod:
                     st.session_state['edit_prod'] = prod
                 else:
                     st.error("Product not found")
             
             if 'edit_prod' in st.session_state:
                 p_data = st.session_state['edit_prod']
                 if p_data['id'] == up_id:
                     with st.form("edit_prod_form"):
                         
                         cat_opts = ["Drinks", "Dairy", "Bakery", "Snacks", "Fruits", "Vegetables", "Frozen", "PersonalCare", "Household", "Other"]
                         try:
                            cat_idx = cat_opts.index(p_data['category'])
                         except:
                            cat_idx = 0
                            
                         en = st.text_input("Name", value=p_data['name'])
                         eb = st.text_input("Brand", value=p_data['brand'])
                         ec = st.selectbox("Category", cat_opts, index=cat_idx)
                         ep = st.number_input("Price", value=float(p_data['price']))
                         # Handle None/null for optional fields
                         op_val = p_data.get('original_price')
                         eop = st.number_input("Old Price (Optional)", value=float(op_val) if op_val else 0.0)
                         es = st.number_input("Stock", value=int(p_data['stock']))
                         
                         rate_val = p_data.get('rating')
                         # Remove widget-level min/max here too
                         er = st.number_input("Rating (0.0 - 5.0)", value=float(rate_val) if rate_val else 0.0, step=0.1)
                         
                         img_val = p_data.get('image')
                         eimg = st.text_input("Image URL", value=img_val if img_val else "")
                         
                         desc_val = p_data.get('description')
                         edesc = st.text_area("Description", value=desc_val if desc_val else "")
                         
                         if st.form_submit_button("Update Product"):
                             if not en.strip() or not eb.strip():
                                 st.error("Name and Brand cannot be empty.")
                             elif ep <= 0:
                                 st.error("Price must be greater than 0.")
                             elif eop < 0 or es < 0:
                                 st.error("Stock and Old Price cannot be negative.")
                             elif er < 0 or er > 5:
                                 st.error("Rating must be between 0 and 5.")
                             else:
                                 payload_up = {
                                     "name": en, "brand": eb, "category": ec, "price": ep, 
                                     "oldPrice": eop if eop > 0 else None, "stock": es,
                                     "description": edesc, "rating": er, "imageUrl": eimg
                                 }
                                 res = api_put(f"/admin/products/{up_id}", payload_up)
                                 if res and res.status_code == 200:
                                     st.success("Product Updated")
                                     if es == 0:
                                         st.warning("Product updated. Status: Out of Stock.")
                                     del st.session_state['edit_prod']
                                 else:
                                     st.error(res.json().get("message", "Failed to update") if res else "Failed Update")

        # List Products
        products = api_get("/products")
        if products:
            df = pd.DataFrame(products)
            st.dataframe(df[['id', 'name', 'brand', 'price', 'stock', 'rating', 'category']])
            
            # Delete
            del_id = st.number_input("Enter ID to Delete", min_value=0)
            if st.button("Delete Product"):
                res = api_delete(f"/admin/products/{del_id}")
                if res and res.status_code == 200:
                    st.success("Product deleted successfully")
                    st.rerun()
                elif res and res.status_code == 404:
                    # Product not found
                    try:
                        error_msg = res.json().get("message", "Product does not exist")
                    except:
                        error_msg = "Product does not exist"
                    st.error(error_msg)
                else:
                    st.error("Failed to delete..\nProduct does not exist!")

    with tab2:
        st.subheader("Store Statistics")
        stats = api_get("/stats")
        if stats:
            c1, c2, c3 = st.columns(3)
            c1.metric("Total Products", stats['totalProducts'])
            c2.metric("Categories", stats['categories'])
            c3.metric("Active Carts", stats['activeCarts'])
        
        st.subheader("Financials")
        inv_stats = api_get("/checkouts/stats")
        if inv_stats:
            c1, c2, c3 = st.columns(3)
            c1.metric("Total Revenue", f"{inv_stats['TotalRevenue']:.2f} EGP")
            c2.metric("Transactions", inv_stats['TotalTransactions'])
            c3.metric("Avg Ticket", f"{inv_stats['AverageTransaction']:.2f} EGP")

    with tab3:
        st.subheader("Transaction History")
        checkouts = api_get("/checkouts")
        if checkouts:
            # Display summary table
            df = pd.DataFrame(checkouts)
            # Ensure Username column exists (in case of old API response cached, though unlikely with direct call)
            if 'Username' not in df.columns:
                df['Username'] = "Guest"
                
            st.dataframe(df[['InvoiceId', 'CheckoutDate', 'Username', 'TotalAmount', 'PaymentMethod', 'ItemsCount']], use_container_width=True)
            
            # Detail View
            st.divider()
            st.subheader("Transaction Details")
            
            # Create a dictionary for easy lookup and formatted labels
            inv_map = {t['InvoiceId']: t for t in checkouts}
            sel_inv = st.selectbox("Select Invoice to View Details", list(inv_map.keys()))
            
            if sel_inv:
                selected = inv_map[sel_inv]
                
                # The 'InvoiceData' is a JSON string, we need to parse it
                try:
                    data = json.loads(selected['InvoiceData'])
                    
                    c1, c2, c3, c4 = st.columns(4)
                    c1.write(f"**Date:** {selected['CheckoutDate']}")
                    c2.write(f"**User:** {selected.get('Username', 'Guest')}")
                    c3.write(f"**Payment:** {selected['PaymentMethod']}")
                    c4.write(f"**Total:** {selected['TotalAmount']:.2f} EGP")
                     
                    st.markdown("#### Items")
                    for item in data['items']:
                        # Handle potential missing keys if schema changed, though it should be consistent
                        p_name = item.get('productName', item.get('name', 'Unknown'))
                        p_brand = item.get('brand', '')
                        p_qty = item.get('quantity', 0)
                        p_price = item.get('unitPrice', item.get('price', 0))
                        
                        st.write(f"- {p_qty}x {p_name} ({p_brand}) @ {p_price:.2f} = {p_qty * p_price:.2f}")
                    
                    st.divider()
                    col_sub, col_tax, col_tot = st.columns(3)
                    col_sub.metric("Subtotal", f"{data.get('subtotal', 0):.2f}")
                    col_tax.metric("Tax", f"{data.get('tax', 0):.2f}")
                    col_tot.metric("Final Total", f"{data.get('finalTotal', 0):.2f}")

                except Exception as e:
                    st.error(f"Could not parse invoice details: {e}")

            st.divider()
            if st.button("Clear All History"):
                if api_delete("/checkouts").status_code == 200:
                    st.success("Cleared")
                    st.rerun()

# --- MAIN NAVIGATION ---

def main():
    
    # Check Auth
    user = st.session_state['user']
    
    if user:
        role = user['role'].lower()
        st.sidebar.markdown(f"👤 **{user['username']}** ({role})")
        if st.sidebar.button("Logout"):
            st.session_state['user'] = None
            st.rerun()
            
        st.sidebar.divider()
        
        if role == 'admin':
            page = st.sidebar.radio("Navigation", ["Dashboard", "Shop Preview"])
            if page == "Dashboard":
                admin_dashboard()
            else:
                shop_page()
        else: # User
            page = st.sidebar.radio("Menu", ["Shop", "Cart", "Transactions"])
            if page == "Shop":
                shop_page()
            elif page == "Cart":
                cart_page()
            elif page == "Transactions":
                user_transactions_page()
            
            # Show cart badge if possible or just count
            cart_stats = api_get("/cart")
            if cart_stats:
                st.sidebar.success(f"Cart: {cart_stats['itemCount']} items")
    else:
        st.sidebar.title("Welcome")
        page = st.sidebar.radio("Menu", ["Login/Register", "Guest Shop"])
        
        if page == "Login/Register":
            login_register_page()
        else:
            shop_page()

if __name__ == "__main__":
    main()